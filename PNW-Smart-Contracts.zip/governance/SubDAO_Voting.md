# SubDAO Fund Voting Rules

Each SubDAO controls its share of the 2% tax collected from worker wages. While voting categories exist, SubDAOs have full autonomy over fund allocation.